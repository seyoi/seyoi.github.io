from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests
from typing import List, Dict

app = FastAPI()

# 네이버 API 자격증명 (API 키를 실제 값으로 바꿔주세요)
CLIENT_ID = 'vJVFVERoF2OcHyl8XN7l'
CLIENT_SECRET = 'WWqxi90iAR'

# 요청 모델
class SearchRequest(BaseModel):
    query: str
    display: int = 10  # 기본 검색 결과 수 (1~100)
    start: int = 1     # 검색 시작 위치 (1~1000)

@app.post("/search_blog")
async def search_blog(request: SearchRequest):
    url = "https://openapi.naver.com/v1/search/blog.json"
    headers = {
        "X-Naver-Client-Id": CLIENT_ID,
        "X-Naver-Client-Secret": CLIENT_SECRET
    }
    params = {
        "query": request.query,
        "display": request.display,
        "start": request.start
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        
        if "items" not in data:
            raise HTTPException(status_code=404, detail="No blog posts found")

        # Extract blog post titles and contents (or other fields as needed)
        blog_posts = [{"title": item["title"], "link": item["link"]} for item in data["items"]]
        return {"blog_posts": blog_posts}
    
    except requests.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Request error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
