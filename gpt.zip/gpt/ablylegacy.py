from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import json
import os
from typing import List, Dict
import openai
from fastapi.middleware.cors import CORSMiddleware
import os
import json
from typing import List, Dict

app = FastAPI()
openai.api_key = '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'

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_FILE_PATH = "chatbots.json"

def read_chatbots():
    print(f"Reading from file: {DATA_FILE_PATH}")
    if os.path.exists(DATA_FILE_PATH):
        try:
            with open(DATA_FILE_PATH, "r") as file:
                data = json.load(file)
                print("Chatbots read successfully.")
                return data
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return []
        except Exception as e:
            print(f"Error reading file: {e}")
            return []
    else:
        print("File does not exist.")
        return []

def write_chatbots(chatbots):
    try:
        with open(DATA_FILE_PATH, "w") as file:
            json.dump(chatbots, file, indent=2)
            file.flush()  # Ensure data is written
        print("Chatbots written successfully.")
    except Exception as e:
        print(f"Error writing to file: {e}")

# Example usage
chatbots = read_chatbots()
print(chatbots)
chatbots.append({"id": 1, "name": "New Chatbot"})
write_chatbots(chatbots) 


class ChatRequest(BaseModel):
    message: str

class DataRequest(BaseModel):
    chatbotId: int
    data: str
    
class Chatbot(BaseModel):
    name: str

    
@app.post("/api/chatbots")
async def create_chatbot(chatbot: Chatbot):
    try:
        chatbots = read_chatbots()
        new_id = chatbots[-1]["id"] + 1 if chatbots else 1
        new_chatbot = {
            "id": new_id,
            "name": chatbot.name,
            "data": []  # Initialize with empty data
        }
        chatbots.append(new_chatbot)
        write_chatbots(chatbots)
        return new_chatbot
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/chatbots/data")
async def submit_data(request: DataRequest):
    try:
        chatbots = read_chatbots()
        chatbot = next((bot for bot in chatbots if bot["id"] == request.chatbotId), None)
        if chatbot:
            if "data" not in chatbot:
                chatbot["data"] = []
            chatbot["data"].append(request.data)
            write_chatbots(chatbots)
            return {"message": "Data submitted successfully"}
        else:
            raise HTTPException(status_code=404, detail="Chatbot not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/chat/")
async def chat(request: ChatRequest):
    try:
        chatbots = read_chatbots()
        chatbot = next((bot for bot in chatbots if "data" in bot), None)
        if chatbot:
            relevant_data = chatbot["data"]
            context = "\n".join(relevant_data)
            # GPT-4 모델에 검색된 데이터를 포함한 요청 보내기
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": request.message},
                    {"role": "system", "content": f"Context: {context}"}
                ]
            )
            reply = response.choices[0].message['content'].strip()
            return {"reply": reply}
        else:
            return {"reply": "No relevant data found"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
