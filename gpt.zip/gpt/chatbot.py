import openai

# Set your API key
openai.api_key = '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'

def get_chat_response(user_input):
    # Create a chat completion request using the updated API
    response = openai.ChatCompletion.create(
        model="gpt-4",  # Ensure this is the correct model name
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": user_input}
        ],
        temperature=0,
        max_tokens=156,
        top_p=0,
        frequency_penalty=1,
        presence_penalty=1,
        
    )
    
    # Extract the response content
    reply = response.choices[0].message['content']
    return reply

# Main loop to accept user input and provide responses
while True:
    user_input = input("You: ")
    if user_input.lower() in ['exit', 'quit']:
        print("Goodbye!")
        break
    
    response = get_chat_response(user_input)
    print(f"Assistant: {response}")
