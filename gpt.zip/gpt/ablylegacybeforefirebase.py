from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import json
import os
from typing import List, Dict
import openai
from fastapi.middleware.cors import CORSMiddleware

from fastapi import FastAPI, HTTPException, Request
import firebase_admin
from firebase_admin import credentials

cred = credentials.Certificate("/Users/matias/Documents/github/seyoi.github.io/gpt/hanna-9d44a-firebase-adminsdk-z3ecc-098497e37f.json")
firebase_admin.initialize_app(cred)



app = FastAPI()

openai.api_key = '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'  # 보안상의 이유로 직접 공개키를 사용하지 말 것

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_FILE_PATH = "chatbots.json"
print(DATA_FILE_PATH)

def read_chatbots():
    print(f"Reading from file: {DATA_FILE_PATH}")
    if os.path.exists(DATA_FILE_PATH):
        try:
            with open(DATA_FILE_PATH, "r") as file:
                data = json.load(file)
                print("Chatbots read successfully.")
                return data
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return []
        except Exception as e:
            print(f"Error reading file: {e}")
            return []
    else:
        print("File does not exist.")
        return []

def write_chatbots(chatbots):
    try:
        with open(DATA_FILE_PATH, "w") as file:
            json.dump(chatbots, file, indent=2)
            file.flush()  # Ensure data is written
        print("Chatbots written successfully.")
    except Exception as e:
        print(f"Error writing to file: {e}")

# Example usage


class ChatRequest(BaseModel):
    message: str

class DataRequest(BaseModel):
    chatbotId: int
    data: str

class Chatbot(BaseModel):
    name: str

@app.post("/api/chatbots")
async def create_chatbot(chatbot: Chatbot):
    try:
        chatbots = read_chatbots()
        new_id = chatbots[-1]["id"] + 1 if chatbots else 1
        new_chatbot = {
            "id": new_id,
            "name": chatbot.name,
            "documents": []  # Initialize with empty documents
        }
        chatbots.append(new_chatbot)
        write_chatbots(chatbots)
        return new_chatbot
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/chatbots/data")
async def submit_data(request: DataRequest):
    try:
        chatbots = read_chatbots()
        chatbot = next((bot for bot in chatbots if bot["id"] == request.chatbotId), None)
        if chatbot:
            if "documents" not in chatbot:
                chatbot["documents"] = []
            chatbot["documents"].append(request.data)
            write_chatbots(chatbots)
            return {"message": "Data submitted successfully"}
        else:
            raise HTTPException(status_code=404, detail="Chatbot not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/chat/")
async def chat(request: ChatRequest):
    try:
        chatbots = read_chatbots()
        chatbot = next((bot for bot in chatbots if "documents" in bot), None)
        if chatbot:
            relevant_data = chatbot["documents"]
            context = "\n".join(relevant_data)
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant. Your responses should be based solely on the provided documents."},
                    {"role": "user", "content": request.message},
                    {"role": "system", "content": f"Context: {context}"}
                ]
            )
            reply = response.choices[0].message['content'].strip()
            return {"reply": reply}
        else:
            return {"reply": "No relevant data found"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/chatbots")
async def get_chatbots():
    try:
        chatbots = read_chatbots()
        return chatbots
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/chatbots")
async def update_chatbot(chatbot: Chatbot):
    try:
        chatbots = read_chatbots()
        index = next((i for i, bot in enumerate(chatbots) if bot["id"] == chatbot.id), None)
        if index is not None:
            chatbots[index] = chatbot.dict()
            write_chatbots(chatbots)
            return chatbot
        else:
            raise HTTPException(status_code=404, detail="Chatbot not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/chatbots")
async def delete_chatbot(request: Request):
    try:
        body = await request.json()
        chatbot_id = body.get("id")
        chatbots = read_chatbots()
        chatbots = [bot for bot in chatbots if bot["id"] != chatbot_id]
        write_chatbots(chatbots)
        return {"message": "Chatbot deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))





# 사용자 모델
class User(BaseModel):
    email: str
    password: str

# 사용자 등록 엔드포인트
@app.post("/register")
async def register_user(user: User):
    try:
        # Firebase Authentication을 사용하여 사용자 등록
        user_record = auth.create_user(
            email=user.email,
            password=user.password
        )
        return {"uid": user_record.uid}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 사용자 인증 엔드포인트
@app.post("/login")
async def login_user(user: User):
    try:
        # Firebase Authentication을 사용하여 사용자 로그인
        user_record = auth.get_user_by_email(user.email)
        return {"uid": user_record.uid}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Firebase Firestore를 사용하여 데이터 저장
from firebase_admin import firestore

db = firestore.client()

@app.post("/add_note")
async def add_note(title: str, content: str):
    try:
        # Firestore에 데이터 추가
        notes_ref = db.collection('notes')
        notes_ref.add({
            'title': title,
            'content': content
        })
        return {"message": "Note added successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))