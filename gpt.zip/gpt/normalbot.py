from fastapi import FastAPI, UploadFile, HTTPException, File, Query, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain_community.llms import OpenAI
import os
import shutil
import openai
import faiss
import numpy as np

app = FastAPI()

openai.api_key = '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'

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 전역 벡터 DB 초기화
embeddings = HuggingFaceEmbeddings()
vector_db = None

def extract_text_from_file(file: UploadFile):
    """파일에서 텍스트를 추출하는 함수"""
    file_path = f"./temp/{file.filename}"
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # 텍스트 파일만 처리
    if file.filename.endswith('.txt'):
        with open(file_path, 'r') as f:
            text = f.read()
    else:
        text = ""
    
    os.remove(file_path)
    return text

@app.post("/api/upload")
async def upload_file(file: UploadFile):
    """파일 업로드를 처리하는 API 엔드포인트"""
    text = extract_text_from_file(file)
    if text:
        global vector_db
        text_chunks = [text]
        embeddings_list = embeddings.embed_documents(text_chunks)
        
        if vector_db is None:
            dim = len(embeddings_list[0])
            index = faiss.IndexFlatL2(dim)
            docstore = {}
            index_to_docstore_id = {}

            vector_db = FAISS(
                embedding_function=embeddings.embed_query,
                docstore=docstore,
                index_to_docstore_id=index_to_docstore_id,
                index=index
            )

        vectors = np.array(embeddings_list)
        ids = list(range(len(vectors)))
        index = vector_db.index
        index.add(vectors)
        
        # 파일 텍스트를 서버에 저장 (프리뷰용)
        preview_path = f"./temp/previews/{file.filename}"
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        with open(preview_path, "w") as f:
            f.write(text)

        return {"message": "File processed, converted to embeddings, and added to the database"}
    else:
        return JSONResponse(status_code=400, content={"message": "Unsupported file format or error extracting text"})

@app.post("/api/upload_text")
async def upload_text(documentText: str = Form(...)):
    """텍스트 업로드를 처리하는 API 엔드포인트"""
    if not documentText.strip():
        return JSONResponse(status_code=400, content={"message": "No text provided"})

    global vector_db
    text_chunks = [documentText]
    embeddings_list = embeddings.embed_documents(text_chunks)

    if vector_db is None:
        dim = len(embeddings_list[0])
        index = faiss.IndexFlatL2(dim)
        docstore = {}
        index_to_docstore_id = {}

        vector_db = FAISS(
            embedding_function=embeddings.embed_query,
            docstore=docstore,
            index_to_docstore_id=index_to_docstore_id,
            index=index
        )

    vectors = np.array(embeddings_list)
    ids = list(range(len(vectors)))
    index = vector_db.index
    index.add(vectors)

    # 업로드된 텍스트를 프리뷰 파일로 저장
    preview_path = f"./temp/previews/text_preview.txt"
    os.makedirs(os.path.dirname(preview_path), exist_ok=True)
    with open(preview_path, "w") as f:
        f.write(documentText)

    return {"message": "Text converted to embeddings and added to the database"}

@app.post("/api/chat")
async def chat(userInput: str = Query(...)):
    try:
        # OpenAI API를 통해 GPT-4 모델에 질문
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "user", "content": userInput}
            ]
        )

        # GPT-4의 응답을 반환
        return {"reply": response.choices[0].message['content'].strip()}
    except Exception as e:
        return JSONResponse(status_code=500, content={"reply": f"Error: {str(e)}"})
    
    
    
# @app.post("/api/chat")
# async def chat(userInput: str = Query(...)):
#     """질문에 대해 답변을 생성하는 API 엔드포인트"""
#     global vector_db
#     if vector_db is None or vector_db.index.ntotal == 0:
#         return JSONResponse(status_code=400, content={"reply": "데이터가 없어서 답변이 불가능합니다. 파일을 업로드하거나 텍스트를 추가해 주세요."})

#     # Check if vector_db is properly initialized and has data
#     if vector_db.index is None or vector_db.index.ntotal == 0:
#         return JSONResponse(status_code=500, content={"reply": "Error: Vector DB is empty or not initialized."})

#     try:
#         llm = OpenAI(model="gpt-4", api_key=openai.api_key)
#         qa_chain = RetrievalQA.from_chain_type(
#             retriever=vector_db.as_retriever(),
#             llm=llm
#         )
#         response = qa_chain.run(userInput)
#         return {"reply": response}
#     except Exception as e:
#         return JSONResponse(status_code=500, content={"reply": f"Error during QA process: {str(e)}"})

@app.get("/api/file_preview/{file_name}")
async def file_preview(file_name: str):
    """업로드된 파일의 미리보기를 제공하는 API 엔드포인트"""
    preview_path = f"./temp/previews/{file_name}"
    if os.path.exists(preview_path):
        try:
            with open(preview_path, 'r') as file:
                text = file.read()
            return {"preview": text}
        except Exception as e:
            return JSONResponse(status_code=500, content={"message": f"Error reading file: {str(e)}"})
    else:
        return JSONResponse(status_code=404, content={"message": "File not found"})

@app.get("/api/vector_db_info")
async def vector_db_info():
    """벡터 DB의 정보를 제공하는 API 엔드포인트"""
    global vector_db
    if vector_db is None:
        return JSONResponse(status_code=404, content={"message": "Vector database not initialized"})

    num_documents = vector_db.index.ntotal
    return {"num_documents": num_documents}