from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import openai
from fastapi.middleware.cors import CORSMiddleware
from sentence_transformers import SentenceTransformer
import faiss
import logging

app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Ensure this matches your frontend origin
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

# Set your OpenAI API key
openai.api_key = 'your_openai_api_key_here'

# Load Sentence Transformer Model
embedding_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# Example Knowledge Base
documents = [
    "The capital of France is Paris.",
    "The Eiffel Tower is one of the most famous landmarks in the world.",
    "FastAPI is a modern, fast web framework for building APIs with Python.",
    "GPT-4 is a powerful language model developed by OpenAI.",
    "대표번호: 007"
]

# Convert documents to embeddings
document_embeddings = embedding_model.encode(documents)

# Initialize FAISS index
index = faiss.IndexFlatL2(document_embeddings.shape[1])
index.add(document_embeddings)

class UserInput(BaseModel):
    userInput: str

@app.post("/api/chat")
async def get_chat_response(input: UserInput):
    try:
        # Encode user input to vector
        query_embedding = embedding_model.encode([input.userInput])
        
        # Perform similarity search
        D, I = index.search(query_embedding, k=3)
        relevant_docs = [documents[i] for i in I[0]]

        # Construct the prompt with relevant documents
        context = "\n".join(relevant_docs)
        prompt = (
            f"The following context is available to answer the question:\n\n"
            f"{context}\n\n"
            f"Based on the context above, respond to the following query:\n"
            f"{input.userInput}\n\n"
            f"Only use the information provided in the context. Do not make up any information."
        )

        # Call the OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=1,
            max_tokens=156,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )

        reply = response['choices'][0]['message']['content']
        return {"reply": reply}

    except Exception as e:
        logging.error(f"Error in /api/chat: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")
